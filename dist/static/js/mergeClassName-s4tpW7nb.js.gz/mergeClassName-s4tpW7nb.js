function r(n,e){return e!==null?typeof e=="string"?[...n,e].join(" "):[...n,...e].join(" "):n.join(" ")}export{r as m};
