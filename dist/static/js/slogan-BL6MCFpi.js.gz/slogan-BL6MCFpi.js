import{_ as o}from"./slogan.vue_vue_type_script_setup_true_lang-ClKLsT0t.js";import"./index-BsGhlh_X.js";import"./__commonjsHelpers__-CqkleIqs.js";export{o as default};
