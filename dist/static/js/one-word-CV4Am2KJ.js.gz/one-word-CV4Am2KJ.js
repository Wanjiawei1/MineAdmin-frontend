import{_ as o}from"./one-word.vue_vue_type_script_setup_true_lang-BxbYRUrx.js";import"./index-fEaXY3hb.js";import"./__commonjsHelpers__-Cpj98o6Y.js";export{o as default};
